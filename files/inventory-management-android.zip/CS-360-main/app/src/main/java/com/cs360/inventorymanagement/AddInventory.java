package com.cs360.inventorymanagement;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.cs360.inventorymanagement.models.Product;
import com.cs360.inventorymanagement.services.IInventoryService;
import com.cs360.inventorymanagement.services.InventoryService;

public class AddInventory extends AppCompatActivity {
    private IInventoryService _inventoryService;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_inventory);

        _inventoryService = new InventoryService(this);
    }

    public void addProduct(View view) {
        EditText skuField = findViewById(R.id.addProductSKU);
        EditText nameField = findViewById(R.id.addProductName);
        EditText quantityField = findViewById(R.id.addProductQuantity);

        String sku = skuField.getText().toString();
        String name = nameField.getText().toString();
        int quantity = Integer.parseInt(quantityField.getText().toString().trim());

        _inventoryService.addProduct(new Product(sku, name, quantity));

        Intent intent = new Intent(AddInventory.this, InventoryActivity.class);
        startActivity(intent);
    }

    public void cancel(View view) {
        Intent intent = new Intent(AddInventory.this, InventoryActivity.class);
        startActivity(intent);
    }
}
