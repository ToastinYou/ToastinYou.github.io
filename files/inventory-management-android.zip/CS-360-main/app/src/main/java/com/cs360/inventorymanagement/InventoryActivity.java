package com.cs360.inventorymanagement;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.GridView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.cs360.inventorymanagement.adapters.InventoryAdapter;
import com.cs360.inventorymanagement.models.Product;
import com.cs360.inventorymanagement.services.IInventoryService;
import com.cs360.inventorymanagement.services.InventoryService;
import java.util.List;

public class InventoryActivity extends AppCompatActivity {
    private IInventoryService _inventoryService;
    private InventoryAdapter _inventoryAdapter;
    private static final int REQUEST_CODE_SMS_PERMISSION = 123;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        _inventoryService = new InventoryService(this);
        _inventoryAdapter = new InventoryAdapter(this, R.layout.inventory_item, _inventoryService.getProducts());

        GridView grid = findViewById(R.id.productsGrid);
        grid.setAdapter(_inventoryAdapter);

        _inventoryAdapter.setOnDeleteClickListener(new InventoryAdapter.OnDeleteClickListener() {
            @Override
            public void onDeleteClick(String sku) {
                deleteProduct(sku);
            }
        });

        _inventoryAdapter.setOnQuantityChangedListener(new InventoryAdapter.OnQuantityChangedListener() {
            @Override
            public void onQuantityChanged(String sku, String newQuantity) {
                updateQuantity(sku, newQuantity);
            }
        });
    }

    private void updateQuantity(String sku, String quantity) {
        _inventoryService.updateQuantity(sku, Integer.parseInt(quantity.trim()));
    }

    public void requestSMSPermission(View view) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) {
            // Request the SMS permission
            ActivityCompat.requestPermissions(this, new String[] { Manifest.permission.READ_SMS }, REQUEST_CODE_SMS_PERMISSION);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_CODE_SMS_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Allowed
            } else {
                // Denied
            }
        }
    }

    private void refreshInventoryData() {
        List<Product> updatedProductList = _inventoryService.getProducts();

        _inventoryAdapter.clear();
        _inventoryAdapter.addAll(updatedProductList);
        _inventoryAdapter.notifyDataSetChanged();
    }

    public void deleteProduct(String sku) {
        _inventoryService.deleteProduct(sku);
        refreshInventoryData();
    }

    public void addProduct(View view) {
        Intent intent = new Intent(InventoryActivity.this, AddInventory.class);
        startActivity(intent);
    }

    public void signOut(View view) {
        Intent intent = new Intent(InventoryActivity.this, MainActivity.class);
        startActivity(intent);
    }
}
