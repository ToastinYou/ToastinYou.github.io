package com.cs360.inventorymanagement;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.cs360.inventorymanagement.models.User;
import com.cs360.inventorymanagement.services.AuthService;
import com.cs360.inventorymanagement.services.IAuthService;

public class MainActivity extends AppCompatActivity {
    private IAuthService _authService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        _authService = new AuthService(this);
    }

    private String getEmailInput() {
        EditText emailEditText = findViewById(R.id.editTextEmail);
        return emailEditText.getText().toString();
    }

    private String getPasswordInput() {
        EditText passwordEditText = findViewById(R.id.editTextPassword);
        return passwordEditText.getText().toString();
    }

    private boolean areInputsInvalid(String email, String password) {
        return email.isEmpty() || password.isEmpty();
    }

    public void login(View view) {
        String email = getEmailInput();
        String password = getPasswordInput();

        if (areInputsInvalid(email, password)) {
            return;
        }

        boolean authorized = _authService.areCredentialsValid(email, password);

        if (!authorized) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Not Authorized");
            builder.setMessage("Invalid login credentials. Please try again or contact support to reset your password.");
            builder.setPositiveButton("OK", (dialog, which) -> { });
            AlertDialog alertDialog = builder.create();
            alertDialog.show();
            return;
        }

        Intent intent = new Intent(MainActivity.this, InventoryActivity.class);
        startActivity(intent);
    }

    public void register(View view) {
        String email = getEmailInput();
        String password = getPasswordInput();

        if (areInputsInvalid(email, password)) {
            return;
        }

        boolean authorized = _authService.areCredentialsValid(email, password);

        if (!authorized) {
            _authService.registerUser(new User(email, password));
        }

        Intent intent = new Intent(MainActivity.this, InventoryActivity.class);
        startActivity(intent);
    }
}