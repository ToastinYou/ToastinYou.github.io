package com.cs360.inventorymanagement.adapters;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import com.cs360.inventorymanagement.R;
import com.cs360.inventorymanagement.models.Product;
import java.util.List;
import java.util.Objects;

public class InventoryAdapter extends ArrayAdapter<Product> {
    private OnQuantityChangedListener quantityChangedListener;
    private OnDeleteClickListener deleteClickListener;

    public InventoryAdapter(@NonNull Context context, int resource, @NonNull List<Product> products) {
        super(context, resource, products);
    }

    public interface OnQuantityChangedListener {
        void onQuantityChanged(String sku, String newQuantity);
    }

    public void setOnQuantityChangedListener(OnQuantityChangedListener listener) {
        this.quantityChangedListener = listener;
    }

    public interface OnDeleteClickListener {
        void onDeleteClick(String sku);
    }

    public void setOnDeleteClickListener(OnDeleteClickListener listener) {
        this.deleteClickListener = listener;
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, @NonNull ViewGroup parent) {
        View grid = convertView;

        if (grid == null) {
            grid = LayoutInflater.from(getContext()).inflate(R.layout.inventory_item, parent, false);
        }

        TextView name = grid.findViewById(R.id.productName);
        TextView sku = grid.findViewById(R.id.productSKU);
        TextView quantity = grid.findViewById(R.id.productQuantity);
        Button deleteButton = grid.findViewById(R.id.deleteBtn);

        Product product = getItem(position);

        name.setText(Objects.requireNonNull(product).getName());
        sku.setText(product.getSKU());
        quantity.setText(String.valueOf(product.getQuantity()));

        quantity.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) { }

            @Override
            public void afterTextChanged(Editable s) {
                if (quantityChangedListener != null) {
                    quantityChangedListener.onQuantityChanged(sku.getText().toString(), s.toString());
                }
            }
        });

        deleteButton.setOnClickListener(v -> {
            if (deleteClickListener != null) {
                deleteClickListener.onDeleteClick(sku.getText().toString());
            }
        });

        return grid;
    }
}
