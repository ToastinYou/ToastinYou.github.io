package com.cs360.inventorymanagement.databases;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.cs360.inventorymanagement.models.Product;
import com.cs360.inventorymanagement.models.User;

import java.util.ArrayList;
import java.util.List;

public class InventoryDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "Inventory.db";
    private static final int VERSION = 1;

    public InventoryDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class UserTable {
        private static final String TABLE = "Users";
        private static final String COL_EMAIL = "Email";
        private static final String COL_PASSWORD = "Password";
    }

    private static final class ProductTable {
        private static final String TABLE = "Items";
        private static final String COL_SKU = "SKU";
        private static final String COL_NAME = "Name";
        private static final String COL_QUANTITY = "Quantity";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + UserTable.TABLE + " (" +
                UserTable.COL_EMAIL + " TEXT PRIMARY KEY, " +
                UserTable.COL_PASSWORD + " TEXT NOT NULL)");

        db.execSQL("CREATE TABLE " + ProductTable.TABLE + " (" +
                ProductTable.COL_SKU + " TEXT PRIMARY KEY, " +
                ProductTable.COL_NAME + " TEXT," +
                ProductTable.COL_QUANTITY + " INTEGER NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + UserTable.TABLE);
        db.execSQL("DROP TABLE IF EXISTS " + ProductTable.TABLE);
        onCreate(db);
    }

    public List<User> getUsers() {
        List<User> users = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + UserTable.TABLE, null);

        if (cursor.moveToFirst()) {
            do {
                int emailIndex = cursor.getColumnIndex(UserTable.COL_EMAIL);
                int passwordIndex = cursor.getColumnIndex(UserTable.COL_PASSWORD);
                String email = cursor.getString(emailIndex);
                String password = cursor.getString(passwordIndex);
                User user = new User(email, password);
                users.add(user);
            } while (cursor.moveToNext());
        }

        cursor.close();
        return users;
    }

    public void addUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserTable.COL_EMAIL, user.getEmail());
        values.put(UserTable.COL_PASSWORD, user.getPassword());
        db.insert(UserTable.TABLE, null, values);
        db.close();
    }

    public List<Product> getProducts() {
        List<Product> products = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + ProductTable.TABLE, null);

        if (cursor.moveToFirst()) {
            do {
                int skuIndex = cursor.getColumnIndex(ProductTable.COL_SKU);
                int nameIndex = cursor.getColumnIndex(ProductTable.COL_NAME);
                int quantityIndex = cursor.getColumnIndex(ProductTable.COL_QUANTITY);
                String sku = cursor.getString(skuIndex);
                String name = cursor.getString(nameIndex);
                int quantity = cursor.getInt(quantityIndex);
                Product product = new Product(sku, name, quantity);
                products.add(product);
            } while (cursor.moveToNext());
        }

        cursor.close();
        return products;
    }

    public void addProduct(Product product) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(ProductTable.COL_SKU, product.getSKU());
        values.put(ProductTable.COL_NAME, product.getName());
        values.put(ProductTable.COL_QUANTITY, product.getQuantity());
        db.insert(ProductTable.TABLE, null, values);
        db.close();
    }

    public void updateQuantity(String sku, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(ProductTable.COL_QUANTITY, quantity);
        db.update(ProductTable.TABLE, values, ProductTable.COL_SKU + " = ?", new String[] { sku });
        db.close();
    }

    public void deleteProduct(String sku) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(ProductTable.TABLE, ProductTable.COL_SKU + " = ?", new String[] { sku });
        db.close();
    }
}
