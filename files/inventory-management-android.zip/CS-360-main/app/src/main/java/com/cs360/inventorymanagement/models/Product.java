package com.cs360.inventorymanagement.models;

import java.util.ArrayList;

public class Product {
    private final String _sku; // Some SKU's start with 0's, thus it should be a String.
    private final String _name;
    private int _quantity;

    public Product(String sku, String name, int quantity) {
        _sku = sku;
        _name = name;
        _quantity = quantity;
    }

    public String getSKU() {
        return _sku;
    }

    public String getName() {
        return _name;
    }

    public int getQuantity() {
        return _quantity;
    }

    /* Increase product's quantity by 1. */
    public void incrementQuantity() {
        _quantity += 1;
    }

    /* Decrease product's quantity by 1. */
    public void decrementQuantity() {
        _quantity -= 1;
    }

    public static ArrayList<Product> getMockProducts() {
        ArrayList<Product> products = new ArrayList<>();
        products.add(new Product("1", "Apple", 500));
        products.add(new Product("2", "Banana", 1000));
        products.add(new Product("3", "Pear", 100));
        return products;
    }
}
