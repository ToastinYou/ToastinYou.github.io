package com.cs360.inventorymanagement.models;

public class User {
    private final String _email;
    private final String _password;

    public User(String email, String password) {
        _email = email;
        _password = password;
    }

    public String getEmail() {
        return _email;
    }

    public String getPassword() {
        return _password;
    }
}
