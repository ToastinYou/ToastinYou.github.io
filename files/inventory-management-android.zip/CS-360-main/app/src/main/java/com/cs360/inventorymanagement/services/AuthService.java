package com.cs360.inventorymanagement.services;

import android.content.Context;

import com.cs360.inventorymanagement.models.User;

import java.util.List;

public class AuthService implements IAuthService {
    private final IDataService _dataService;

    public AuthService(Context context) {
        _dataService = new DataService(context);
    }

    @Override
    public boolean areCredentialsValid(String email, String password) {
        List<User> users = _dataService.getUsers();
        return users.stream().anyMatch(user -> user.getEmail().equals(email) && user.getPassword().equals(password));
    }

    @Override
    public void registerUser(User user) {
        _dataService.addUser(user);
    }
}
