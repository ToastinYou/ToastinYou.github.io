package com.cs360.inventorymanagement.services;

import android.content.Context;

import com.cs360.inventorymanagement.databases.InventoryDatabase;
import com.cs360.inventorymanagement.models.Product;
import com.cs360.inventorymanagement.models.User;
import java.util.List;

public class DataService implements IDataService {
    private final InventoryDatabase _db;

    public DataService(Context context) {
        _db = new InventoryDatabase(context);
    }

    @Override
    public List<User> getUsers() {
        return _db.getUsers();
    }

    @Override
    public void addUser(User user) {
        _db.addUser(user);
    }

    public List<Product> getProducts() {
        return _db.getProducts();
    }

    @Override
    public void addProduct(Product product) {
        _db.addProduct(product);
    }

    @Override
    public void updateQuantity(String sku, int quantity) {
        _db.updateQuantity(sku, quantity);
    }

    @Override
    public void deleteProduct(String sku) {
        _db.deleteProduct(sku);
    }
}
