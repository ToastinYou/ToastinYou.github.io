package com.cs360.inventorymanagement.services;

import com.cs360.inventorymanagement.models.User;

public interface IAuthService {
    boolean areCredentialsValid(String email, String password);
    void registerUser(User user);
}
