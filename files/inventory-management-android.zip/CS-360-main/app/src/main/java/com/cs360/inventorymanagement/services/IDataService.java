package com.cs360.inventorymanagement.services;

import com.cs360.inventorymanagement.models.Product;
import com.cs360.inventorymanagement.models.User;

import java.util.List;

public interface IDataService {
    List<User> getUsers();
    void addUser(User user);

    List<Product> getProducts();
    void addProduct(Product product);
    void updateQuantity(String sku, int quantity);
    void deleteProduct(String sku);
}
