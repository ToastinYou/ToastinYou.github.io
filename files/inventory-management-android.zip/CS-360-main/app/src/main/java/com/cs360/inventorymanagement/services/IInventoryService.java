package com.cs360.inventorymanagement.services;

import com.cs360.inventorymanagement.models.Product;

import java.util.List;

public interface IInventoryService {
    List<Product> getProducts();
    void addProduct(Product product);
    void updateQuantity(String sku, int quantity);
    void deleteProduct(String sku);
}
