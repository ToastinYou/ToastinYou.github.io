package com.cs360.inventorymanagement.services;

import android.content.Context;

import com.cs360.inventorymanagement.models.Product;

import java.util.List;

public class InventoryService implements IInventoryService {
    private final IDataService _dataService;

    public InventoryService(Context context) {
        _dataService = new DataService(context);
    }

    public List<Product> getProducts() {
        return _dataService.getProducts();
    }

    public void addProduct(Product product) {
        _dataService.addProduct(product);
    }

    public void updateQuantity(String sku, int quantity) {
        _dataService.updateQuantity(sku, quantity);
    }

    public void deleteProduct(String sku) {
        _dataService.deleteProduct(sku);
    }
}
